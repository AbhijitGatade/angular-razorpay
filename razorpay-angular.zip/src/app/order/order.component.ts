import { Component, HostListener, OnInit } from '@angular/core';
import { OrderService } from '../order.service';

declare var Razorpay: any;
@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit {

  form: any = {};
  paymentId: string = "";
  error: any = "";
  message:string = "Waiting";

  constructor(private orderService: OrderService) { }

  options = {
    "key": "rzp_live_swPK7rd1Iy42Cf",
    "amount": "2",
    "name": "Abhijit Gatade",
    "description": "Web Development",
    "image": "https://www.javachinna.com/wp-content/uploads/2020/02/android-chrome-512x512-1.png",
    "order_id":"",
    "handler": function (response: any){
        var event = new CustomEvent("payment.success",
            {
                detail: response,
                bubbles: true,
                cancelable: true
            }
        );
        window.dispatchEvent(event);
    }
    ,
    "prefill": {
    "name": "",
    "email": "",
    "contact": ""
    },
    "notes": {
    "address": ""
    },
    "theme": {
    "color": "#3399cc"
    }
    };

    ngOnInit(): void {

    }

    onSubmit(): void {
        this.paymentId = '';
        this.error = '';
        // this.orderService.createOrder(this.form).subscribe(
        // data => {
            this.options.key = "rzp_live_swPK7rd1Iy42Cf";
            //this.options.order_id = "1234";
            this.options.amount = "200"; //paise
            this.options.prefill.name = "Abhijit Gatade";
            this.options.prefill.email = "gatadeabhijit@gmail.com";
            this.options.prefill.contact = "9561320192";
            var rzp1 = new Razorpay(this.options);
            rzp1.open();

            rzp1.on('payment.failed', function (response: any){
                // Todo - store this information in the server
                console.log(response.error.code);
                console.log(response.error.description);
                console.log(response.error.source);
                console.log(response.error.step);
                console.log(response.error.reason);
                console.log(response.error.metadata.order_id);
                console.log(response.error.metadata.payment_id);
                //this.error = response.error.reason;
            }
        );
        // }
        // ,
        // err => {
        //     this.error = err.error.message;
        // }
        // );
    }

    @HostListener('window:payment.success', ['$event'])
    onPaymentSuccess(event: any): void {
        // this.orderService.updateOrder(event.detail).subscribe(
        // data => {
        //     this.paymentId = data.message;
        // }
        // ,
        // err => {
        //     this.error = err.error.message;
        // }
        //);
        this.message = "Success";
    }

}
